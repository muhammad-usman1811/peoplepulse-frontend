import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import AuthLayout from '../components/AuthLayout';
import Input from '../components/Input';
import { GoogleIcon, MicrosoftIcon, CheckCircleIcon } from '../components/Icons';

export const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [loginStatus, setLoginStatus] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value
    }));
    if (loginStatus) setLoginStatus(null);
  };

  const handleFillDemo = () => {
    setFormData({
      email: 'admin@peoplepulse.com',
      password: 'password123'
    });
    setLoginStatus(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    setLoginStatus(null);

    setTimeout(() => {
      setIsLoading(false);
      setLoginStatus({
        type: 'success',
        message: `Welcome back, Super Admin! Logged in as ${formData.email}`
      });
    }, 600);
  };

  const handleGoogleSignIn = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setFormData({
        email: 'alex.morgan@gmail.com',
        password: '••••••••••••'
      });
      setLoginStatus({
        type: 'success',
        message: 'Google authentication successful!'
      });
    }, 500);
  };

  const handleMicrosoftSignIn = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setFormData({
        email: 'alex.m@corporate.onmicrosoft.com',
        password: '••••••••••••'
      });
      setLoginStatus({
        type: 'success',
        message: 'Microsoft corporate authentication successful!'
      });
    }, 500);
  };

  return (
    <AuthLayout>
      <div className="form-header">
        <h2>Welcome back</h2>
        <p>Enter your credentials to access your account</p>
      </div>

      {loginStatus && (
        <div className="success-banner">
          <CheckCircleIcon />
          <div>
            <p><strong>Authentication successful</strong></p>
            <span>{loginStatus.message}</span>
          </div>
        </div>
      )}

      <form className="auth-form" onSubmit={handleSubmit}>
        <Input
          id="work-email"
          name="email"
          label="Work email"
          type="email"
          placeholder="name@company.com"
          value={formData.email}
          onChange={handleChange}
          required
          autoComplete="email"
        />

        <Input
          id="password"
          name="password"
          label="Password"
          type="password"
          placeholder="••••••••"
          value={formData.password}
          onChange={handleChange}
          required
          autoComplete="current-password"
          rightLabelElement={
            <Link to="/forgot-password" className="forgot-password-link">
              Forgot password?
            </Link>
          }
        />

        <button type="submit" className="btn-primary" disabled={isLoading}>
          {isLoading ? 'Signing in...' : 'Sign in'}
        </button>

        <div className="auth-divider">
          <span>or</span>
        </div>

        <div className="social-buttons-container">
          <button
            type="button"
            className="btn-social"
            onClick={handleGoogleSignIn}
            disabled={isLoading}
          >
            <GoogleIcon />
            <span>Sign in with Google</span>
          </button>

          <button
            type="button"
            className="btn-social"
            onClick={handleMicrosoftSignIn}
            disabled={isLoading}
          >
            <MicrosoftIcon />
            <span>Sign in with Microsoft</span>
          </button>
        </div>

        <div className="demo-credentials-box">
          <div className="demo-creds-info">
            <span className="demo-tag">Demo Creds</span>
            <code>admin@peoplepulse.com</code> / <code>password123</code>
          </div>
          <button
            type="button"
            className="btn-auto-fill"
            onClick={handleFillDemo}
          >
            Auto Fill
          </button>
        </div>
      </form>
    </AuthLayout>
  );
};

export default Login;
