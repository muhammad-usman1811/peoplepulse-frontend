import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import AuthLayout from '../components/AuthLayout';
import Input from '../components/Input';
import { ArrowLeftIcon, CheckCircleIcon } from '../components/Icons';

export const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (email) {
      setIsSubmitted(true);
      console.log('Password reset requested for:', email);
    }
  };

  return (
    <AuthLayout>
      <div className="back-link-wrapper">
        <Link to="/login" className="back-link">
          <ArrowLeftIcon />
          <span>Back to login</span>
        </Link>
      </div>

      <div className="form-header">
        <h2>Reset your password</h2>
        <p>
          Enter your work email address and we'll send you a link to reset your password.
        </p>
      </div>

      {isSubmitted && (
        <div className="success-banner">
          <CheckCircleIcon />
          <div>
            <p><strong>Reset link sent!</strong></p>
            <span>We've sent password reset instructions to <strong>{email}</strong>.</span>
          </div>
        </div>
      )}

      <form className="auth-form" onSubmit={handleSubmit}>
        <Input
          id="reset-email"
          name="email"
          label="Work email"
          type="email"
          placeholder="name@company.com"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          autoComplete="email"
        />

        <button type="submit" className="btn-primary">
          {isSubmitted ? 'Resend reset link' : 'Send reset link'}
        </button>
      </form>
    </AuthLayout>
  );
};

export default ForgotPassword;
